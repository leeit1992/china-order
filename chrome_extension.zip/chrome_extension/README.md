29/09/2014: Sửa dịch: lấy từ server vứt vào addon.
1.7: Fix Homeland
1.8: Fix get price alibaba